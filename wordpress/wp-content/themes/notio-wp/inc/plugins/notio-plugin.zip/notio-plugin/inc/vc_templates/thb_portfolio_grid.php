<?php function thb_portfolio_grid( $atts, $content = null ) {
	$atts = vc_map_get_attributes( 'thb_portfolio_grid', $atts );
	extract( $atts );
	$filter_categories_array = $filter_categories ? explode( ',', $filter_categories ) : false;
	$source_data             = VcLoopSettings::parseData( $source );
	$query_builder           = new ThbLoopQueryBuilder( $source_data );
	$posts                   = $query_builder->build();
	$posts                   = $posts[1];
	if ( $posts->have_posts() ) {
		while ( $posts->have_posts() ) :
			$posts->the_post();
			$portfolio_id_array[] = get_the_ID();
		endwhile;
	}
	$rand = wp_rand( 0, 1000 );
	ob_start();

	$thb_margins = $thb_margins ? 'thb_margins' : 'no-padding';

	$classes[] = 'thb-portfolio masonry row';
	$classes[] = $thb_margins;
	$classes[] = 'thb-filter-' . $filter_style;

	$btn_classes[] = 'masonry_btn btn';
	$btn_classes[] = $loadmore_style;
	?>

	<section class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" data-thb-animation="<?php echo esc_attr( $animation_style ); ?>" data-thb-animation-speed="<?php echo esc_attr( $animation_speed ); ?>" data-loadmore="#loadmore-<?php echo esc_attr( $rand ); ?>" data-filter="thb-filter-<?php echo esc_attr( $rand ); ?>" data-security="<?php echo esc_attr( wp_create_nonce( 'thb_ajax' ) ); ?>">

		<?php do_action( 'thb-render-filter', $filter_categories_array, $rand, $filter_style, $portfolio_id_array ); ?>
		<?php
		$i          = 1;
		$image_size = $true_aspect ? 'notio-masonry-x2' : 'notio-square-x2';
		$thb_size   = array(
			'class'      => $columns . ' padding-1',
			'image_size' => $image_size,
		);
		while ( $posts->have_posts() ) :
			$posts->the_post();

			set_query_var( 'thb_size', $thb_size );

			if ( $style === 'style1' ) {
				set_query_var( 'thb_hover_style', $hover_style );
			} else {
				set_query_var( 'thb_hover_style', $style2_hover_style );
			}
			set_query_var( 'thb_masonry', $true_aspect );
			set_query_var( 'thb_title_position', $title_position );
			set_query_var( 'thb_animation', $animation_style );
			get_template_part( 'inc/templates/portfolio/' . $style );
			$i++;
endwhile; // end of the loop.
		?>
	</section>
	<?php
	if ( $loadmore ) {
		wp_localize_script(
			'thb-app',
			'portfolioajax',
			array(
				'thb_i'              => $i,
				'aspect'             => $true_aspect,
				'columns'            => $columns . ' padding-1',
				'style'              => $style,
				'count'              => $source_data['size'],
				'loop'               => $source,
				'thb_size'           => $thb_size,
				'thb_hover_style'    => 'style1' === $style ? $hover_style : $style2_hover_style,
				'thb_title_position' => $title_position,
			)
		);
		?>
	<div class="text-center">
		<a class="<?php echo esc_attr( implode( ' ', $btn_classes ) ); ?>" href="#" id="loadmore-<?php echo esc_attr( $rand ); ?>"><?php esc_html_e( 'Load More', 'notio' ); ?></a>
	</div>
	<?php } ?>

	<?php
	$out = ob_get_clean();

	wp_reset_postdata();

	return $out;
}
thb_add_short( 'thb_portfolio_grid', 'thb_portfolio_grid' );
